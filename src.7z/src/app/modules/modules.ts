/**
 * Created by Muhammed Atallah on 4/25/2018.
 */
export class Product {
  productID: number = null;
  name: string = '';
  description: string = '';
  minPrice: number = 0;
  maxPrice: number = 0;
}
