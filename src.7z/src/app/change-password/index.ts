export * from './change-password.component';
