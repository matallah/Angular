import {Injectable} from "@angular/core";
import {ConfigService} from "./config.service";
import {ApiService} from "./api.service";
import {HttpHeaders} from "@angular/common/http";
/**
 * Created by Muhammed Atallah on 4/25/2018.
 */
@Injectable()
export class ProductService {
  constructor(private apiService: ApiService,
              private config: ConfigService) {
  }

  doSaveProduct(product) {
    const httpHeaders = new HttpHeaders({
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    });
    return this.apiService.post(this.config.product_url, JSON.stringify(product), httpHeaders).map(() => {
      console.log("Save success");
    });
  }

  getAllProducts() {
    return this.apiService.get(this.config.products_url);
  }
}
