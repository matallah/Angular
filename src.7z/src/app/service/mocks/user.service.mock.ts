export class MockUserService {

  currentUser = {};

}
