export * from './forbidden.component';
